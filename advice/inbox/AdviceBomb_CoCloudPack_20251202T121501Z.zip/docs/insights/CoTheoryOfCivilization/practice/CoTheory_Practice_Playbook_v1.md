
CoTheory Practice Playbook - v1

Goal: ship trailers, index them, and let assets push upward with proposals.

Add a .cotrail.yaml or .cotrail.json beside important assets.

Run tools/CoTrailer-Validate.ps1 -RepoPath . locally.

Open PR. The guard validates trailers and publishes a CoCloud map.

Use the map to spot synergy clusters. Create merge or partner proposals.

Steward circles approve, adjust, or reject proposals with receipts.

Signals to watch: trailer count, synergy edges, rollback frequency, readiness shifts.
